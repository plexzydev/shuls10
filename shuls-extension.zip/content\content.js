// Content Script: Floating panel + Chat badges + Chat styling on kick.com
const API_URL = 'http://localhost:3001';

let CHANNEL_SLUG = 'shuls10';
let chatConfig = null;
let badgeData = {};
let badgeRefreshInterval = null;

// Load channel from storage then init if on the right page
(async function boot() {
    try {
        const data = await chrome.storage.local.get('channel');
        if (data.channel) CHANNEL_SLUG = data.channel.toLowerCase();
    } catch (e) {}

    const path = window.location.pathname.toLowerCase().replace(/^\//, '').split('/')[0];
    if (path === CHANNEL_SLUG) {
        init();
    }
})();

async function init() {
    console.log('[Shuls Extension] Activada en canal de Shuls');
    injectPanel();

    // Fetch config and badges
    chatConfig = await fetchChatConfig();
    await refreshBadges();

    // Apply chat styling (always, wallpaper is hardcoded)
    applyChatStyling(chatConfig);

    // Observe chat for new messages
    observeChat();

    // Refresh badge data every 2 minutes
    badgeRefreshInterval = setInterval(refreshBadges, 120000);

    // Start role detection sync (sends detected roles to backend every 30s)
    startRoleSync();

    // Start falling gift drop system
    startGiftDropSystem();
}

// Detected roles buffer - sent to backend periodically
let detectedRolesBuffer = {};
let rolesSyncInterval = null;
// Message tracking buffer - sent to backend every 30s for challenge progress
let messageBuffer = [];

async function refreshBadges() {
    try {
        const r = await fetch(`${API_URL}/api/extension/chat-badges`);
        if (r.ok) {
            const data = await r.json();
            badgeData = data.badges || {};
            console.log(`[Shuls] Loaded ${Object.keys(badgeData).length} user badges`);
        }
    } catch (e) {}
}

// Send detected roles and messages to backend every 30 seconds
function startRoleSync() {
    rolesSyncInterval = setInterval(async () => {
        // Sync roles
        const entries = Object.entries(detectedRolesBuffer);
        if (entries.length > 0) {
            const detectedRoles = entries.map(([username, role]) => ({ username, role }));
            detectedRolesBuffer = {};
            try {
                await fetch(`${API_URL}/api/extension/chat-roles`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ detectedRoles })
                });
                console.log(`[Shuls] Synced ${detectedRoles.length} detected roles to backend`);
            } catch (e) {}
        }

        // Sync messages for challenge progress
        if (messageBuffer.length > 0) {
            const messages = [...messageBuffer];
            messageBuffer = [];
            try {
                await fetch(`${API_URL}/api/extension/chat-messages`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ messages })
                });
                console.log(`[Shuls] Synced ${messages.length} messages for challenges`);
            } catch (e) {}
        }
    }, 30000);
}


// ========== CHAT STYLING ==========
function applyChatStyling(config) {
    const theme = config?.theme || {};
    const BG_IMAGE = 'https://wallpaper.forfun.com/fetch/4e/4e8b61705aea3fe461bdab75e62e0c8f.jpeg';

    const style = document.createElement('style');
    style.id = 'shuls-chat-style';
    style.textContent = `
        /* Shuls Chat Background - wallpaper image */
        #chatroom,
        [id*="chatroom"],
        [class*="chatroom"],
        .chatroom {
            position: relative !important;
        }
        #chatroom::before,
        [id*="chatroom"]::before,
        [class*="chatroom"]::before,
        .chatroom::before {
            content: '';
            position: absolute;
            inset: 0;
            background-image: url('${BG_IMAGE}');
            background-size: cover;
            background-position: center;
            opacity: 0.12;
            pointer-events: none;
            z-index: 0;
        }
        #chatroom::after,
        [id*="chatroom"]::after,
        [class*="chatroom"]::after,
        .chatroom::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(12,15,13,0.92) 0%, rgba(27,67,50,0.85) 50%, rgba(12,15,13,0.95) 100%);
            pointer-events: none;
            z-index: 0;
        }
        #chatroom > *,
        [id*="chatroom"] > *,
        [class*="chatroom"] > *,
        .chatroom > * {
            position: relative;
            z-index: 1;
        }

        /* Subtle top accent border */
        #chatroom,
        [class*="chatroom"] {
            border-top: 2px solid transparent !important;
            border-image: linear-gradient(90deg, transparent, ${theme.primary || '#52B788'}50, ${theme.accent || '#C9A84C'}30, transparent) 1 !important;
        }

        /* Chat message hover effect */
        [class*="chat-entry"]:hover,
        [data-chat-entry]:hover,
        [class*="message"]:hover {
            background: rgba(82,183,136,0.06) !important;
            border-radius: 6px;
        }

        /* Shuls custom badge */
        .shuls-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            border-radius: 5px;
            vertical-align: middle;
            animation: shulsBadgePop 0.3s cubic-bezier(0.16,1,0.3,1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .shuls-badge:hover {
            transform: scale(1.2);
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .shuls-badge svg {
            width: 12px;
            height: 12px;
        }
        .shuls-badges-container {
            display: inline-flex !important;
            align-items: center !important;
            gap: 3px !important;
            margin-right: 5px !important;
            vertical-align: middle !important;
        }

        /* Streamer message highlight */
        .shuls-streamer-msg {
            border-left: 3px solid ${theme.accent || '#C9A84C'} !important;
            background: rgba(201,168,76,0.06) !important;
            border-radius: 4px;
            padding-left: 8px !important;
        }

        @keyframes shulsBadgePop {
            0% { opacity: 0; transform: scale(0.7); }
            100% { opacity: 1; transform: scale(1); }
        }
    `;
    document.head.appendChild(style);

    // Also try to directly apply background via JS to the chat panel (more reliable than CSS selectors)
    setTimeout(() => applyBackgroundToChat(BG_IMAGE), 3000);
    setTimeout(() => applyBackgroundToChat(BG_IMAGE), 8000);
    setTimeout(() => applyBackgroundToChat(BG_IMAGE), 15000);
    console.log('[Shuls] Chat styling injected with background image');
}

function applyBackgroundToChat(bgUrl) {
    // Find the chat panel by looking for the scrollable area with messages
    const candidates = document.querySelectorAll('div[class]');
    for (const div of candidates) {
        const style = window.getComputedStyle(div);
        if ((style.overflowY === 'scroll' || style.overflowY === 'auto') && div.children.length > 3) {
            const hasLinks = div.querySelectorAll('a[href^="/"]').length > 2;
            if (hasLinks && !div.dataset.shulsBg) {
                div.dataset.shulsBg = 'true';
                div.style.position = 'relative';
                // Create overlay
                const overlay = document.createElement('div');
                overlay.className = 'shuls-chat-bg-overlay';
                overlay.style.cssText = `
                    position: absolute; inset: 0; pointer-events: none; z-index: 0;
                    background-image: url('${bgUrl}');
                    background-size: cover; background-position: center;
                    opacity: 0.1;
                `;
                const gradient = document.createElement('div');
                gradient.className = 'shuls-chat-bg-gradient';
                gradient.style.cssText = `
                    position: absolute; inset: 0; pointer-events: none; z-index: 0;
                    background: linear-gradient(180deg, rgba(12,15,13,0.93) 0%, rgba(27,67,50,0.85) 50%, rgba(12,15,13,0.95) 100%);
                `;
                div.insertBefore(gradient, div.firstChild);
                div.insertBefore(overlay, div.firstChild);
                // Make children relative
                for (const child of div.children) {
                    if (!child.classList.contains('shuls-chat-bg-overlay') && !child.classList.contains('shuls-chat-bg-gradient')) {
                        child.style.position = 'relative';
                        child.style.zIndex = '1';
                    }
                }
                console.log('[Shuls] Background image applied directly to chat container');
                return;
            }
        }
    }
}

// ========== CHAT OBSERVER ==========
function observeChat() {
    // Observe entire document - pass every new element through processMsg
    const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
            for (const n of m.addedNodes) {
                if (n.nodeType !== 1) continue;
                processMsg(n);
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    console.log('[Shuls] Global chat observer started on document.body');

    // Scan existing messages after delays (chat may already have content)
    setTimeout(() => scanExistingMessages(), 3000);
    setTimeout(() => scanExistingMessages(), 8000);
    setTimeout(() => scanExistingMessages(), 15000);
}

function scanExistingMessages() {
    // Find all elements that look like chat messages and process them
    const allNodes = document.querySelectorAll('.group.relative, [class*="chat-entry"], [data-chat-entry]');
    let processed = 0;
    allNodes.forEach(node => {
        if (!node.dataset?.shulsProcessed && node.querySelector('span[style*="color"]')) {
            processSingleMsg(node);
            processed++;
        }
    });
    // Also try: find colored spans and walk up to a processable parent
    if (processed === 0) {
        const coloredSpans = document.querySelectorAll('span[style*="color"]');
        const seen = new Set();
        for (const span of coloredSpans) {
            const text = span.textContent?.trim();
            if (!text || text.length < 2 || text.length > 25 || text.includes(' ') || /^\d{1,2}:\d{2}/.test(text)) continue;
            // Walk up max 5 levels to find a div we can process
            let target = span.parentElement;
            for (let i = 0; i < 5 && target; i++) {
                if (target.dataset?.shulsProcessed || seen.has(target)) break;
                if (target.tagName === 'DIV' && target.querySelector('span[style*="color"]')) {
                    seen.add(target);
                    processSingleMsg(target);
                    processed++;
                    break;
                }
                target = target.parentElement;
            }
        }
    }
    if (processed > 0) console.log(`[Shuls] Scanned and processed ${processed} existing chat messages`);
}

let debugCount = 0;
function processMsg(node) {
    if (!node || !node.querySelector) return;

    // Kick uses a virtualized list - node might be a container with multiple messages
    // Find all individual message rows within this node
    const messageRows = node.querySelectorAll('.group.relative');
    if (messageRows.length > 0) {
        messageRows.forEach(row => processSingleMsg(row));
        return;
    }

    // Or this node itself might be a message row
    if (node.classList?.contains('group') || node.querySelector('.break-words')) {
        processSingleMsg(node);
    }
}

function processSingleMsg(node) {
    if (!node || node.dataset?.shulsProcessed) return;
    node.dataset.shulsProcessed = 'true';

    // Skip nodes outside the chat area (e.g. points display, nav elements)
    if (node.closest && (node.closest('nav') || node.closest('header') || node.closest('[class*="channel-points"]') || node.closest('[class*="sidebar"]'))) return;

    // In Kick's chat, username is shown as a colored span with font-bold/font-semibold 
    // inside the message div, typically followed by ": " and the message text
    let usernameEl = null;
    let username = '';

    // Strategy 1: Find the chat-message-identity or username wrapper
    usernameEl = node.querySelector('[class*="chat-message-identity"] span[class*="font-bold"]');
    if (!usernameEl) usernameEl = node.querySelector('[class*="chat-message-identity"] span[class*="font-semibold"]');

    // Strategy 2: Find a bold/semibold span with a color style (Kick colors usernames)
    if (!usernameEl) {
        const candidates = node.querySelectorAll('span[class*="font-bold"][style*="color"], span[class*="font-semibold"][style*="color"], button[class*="font-bold"][style*="color"], span.font-bold, span.font-semibold');
        for (const el of candidates) {
            const text = el.textContent?.trim();
            // Username: short text, no spaces, not a timestamp, not purely numeric
            if (text && text.length >= 2 && text.length < 26 && !text.includes(' ') && !/^\d{1,2}:\d{2}$/.test(text) && !/^[\d,.]+$/.test(text)) {
                usernameEl = el;
                break;
            }
        }
    }

    // Strategy 3: Find a clickable username (button or link that triggers user popup)
    if (!usernameEl) {
        const buttons = node.querySelectorAll('button[class*="inline"], button span[style*="color"]');
        for (const btn of buttons) {
            const text = btn.textContent?.trim();
            if (text && text.length >= 2 && text.length < 26 && !text.includes(' ') && !/^\d/.test(text) && !/^[\d,.]+$/.test(text)) {
                usernameEl = btn;
                break;
            }
        }
    }

    // Strategy 4: Look for colored text that appears before a colon or message content
    if (!usernameEl) {
        const allSpans = node.querySelectorAll('span[style*="color"]');
        for (const s of allSpans) {
            const text = s.textContent?.trim();
            const color = s.style?.color;
            // Username spans have a color and contain a short word (the username)
            if (text && text.length >= 2 && text.length < 26 && !text.includes(' ') && color && !/^\d{1,2}:\d{2}$/.test(text) && !/^[\d,.]+$/.test(text)) {
                usernameEl = s;
                break;
            }
        }
    }

    if (!usernameEl) return;

    username = usernameEl.textContent?.trim().toLowerCase().replace(/[:\s]/g, '');
    if (!username || username.length < 2) return;
    // Reject purely numeric strings (e.g. Kick's points counter "210")
    if (/^[\d,.]+$/.test(username)) return;

    // Debug: log first few found usernames
    if (debugCount < 5) {
        debugCount++;
        console.log(`[Shuls] Found username: "${username}" via`, usernameEl.tagName, usernameEl.getAttribute('class')?.substring(0, 40));
    }

    // Track message for challenge progress
    messageBuffer.push({ username });

    // Highlight streamer messages (only once)
    if (username === CHANNEL_SLUG && !node.classList.contains('shuls-streamer-msg')) {
        node.classList.add('shuls-streamer-msg');
        detectedRolesBuffer[username] = 'broadcaster';
        if (!badgeData[username]) badgeData[username] = {};
        badgeData[username].role = 'broadcaster';
    }

    // Detect role from Kick's native badge elements near the username
    const detectedRole = detectRoleNearUsername(node, usernameEl);
    if (detectedRole && username) {
        const rolePriority = { broadcaster: 4, moderator: 3, vip: 2, subscriber: 1 };
        const currentRole = badgeData[username]?.role;
        const currentPri = rolePriority[currentRole] || 0;
        const newPri = rolePriority[detectedRole] || 0;
        // Only set if higher priority (broadcaster > mod > vip > sub)
        if (newPri > currentPri) {
            detectedRolesBuffer[username] = detectedRole;
            if (!badgeData[username]) badgeData[username] = {};
            badgeData[username].role = detectedRole;
        }
        if (debugCount <= 6) {
            console.log(`[Shuls] Detected role "${detectedRole}" for "${username}"`);
        }
    }

    // Inject badges (role, watchtime, custom) if user has any badge data
    const userData = badgeData[username] || {};
    if (userData.role || userData.watchTimeBadge || userData.badges || userData.customBadges) {
        if (!usernameEl.parentElement?.querySelector('.shuls-badges-container')) {
            injectBadges(usernameEl, userData);
        }
    }
}

// Detect role by looking at elements near/before the username element
function detectRoleNearUsername(node, usernameEl) {
    try {
        // Look at the message row for any badge-like elements (images, svgs) that appear BEFORE the username
        // Kick renders mod/vip/sub badges as small icons before the username text
        const parent = usernameEl.parentElement || node;
        
        // Get all images and svgs in the same message row
        const icons = parent.querySelectorAll('img, svg');
        
        // Also check the broader node
        const allIcons = node.querySelectorAll('img[src], svg');
        const combined = new Set([...icons, ...allIcons]);
        
        let highestRole = null;
        const rolePriority = { broadcaster: 4, moderator: 3, vip: 2, subscriber: 1 };

        for (const icon of combined) {
            const src = (icon.getAttribute('src') || '').toLowerCase();
            const alt = (icon.getAttribute('alt') || '').toLowerCase();
            const title = (icon.getAttribute('title') || '').toLowerCase();
            const cls = (icon.getAttribute('class') || '').toLowerCase();
            const ariaLabel = (icon.getAttribute('aria-label') || '').toLowerCase();
            const parentTitle = (icon.parentElement?.getAttribute('title') || '').toLowerCase();
            const parentAria = (icon.parentElement?.getAttribute('aria-label') || '').toLowerCase();
            
            const all = `${src} ${alt} ${title} ${cls} ${ariaLabel} ${parentTitle} ${parentAria}`;

            // Skip avatars/profile pics (larger images)
            if (src.includes('profile') || src.includes('avatar') || icon.width > 30 || icon.height > 30) continue;
            
            let role = null;
            if (all.includes('owner') || all.includes('broadcaster') || all.includes('streamer')) {
                role = 'broadcaster';
            } else if (all.includes('moderator') || all.includes('mod')) {
                role = 'moderator';
            } else if (all.includes('vip')) {
                role = 'vip';
            } else if (all.includes('sub') || all.includes('subscriber')) {
                role = 'subscriber';
            }

            // If no text-based detection, check if it's a small badge icon (Kick uses small green sword for mod, etc)
            // Any small icon (<24px) that's not a profile pic is likely a badge
            if (!role && (icon.tagName === 'svg' || (icon.tagName === 'IMG' && src.includes('badge')))) {
                // Check SVG content for known paths/shapes
                if (icon.tagName === 'svg') {
                    const svgHTML = icon.outerHTML?.toLowerCase() || '';
                    if (svgHTML.includes('m11') || svgHTML.includes('sword') || svgHTML.includes('shield')) {
                        role = 'moderator';
                    }
                }
            }

            if (role && (!highestRole || rolePriority[role] > rolePriority[highestRole])) {
                highestRole = role;
            }
        }

        // Also check for Kick's badge wrapper divs (they often have title/aria-label with the role)
        const wrappers = node.querySelectorAll('[title], [aria-label]');
        for (const w of wrappers) {
            const title = (w.getAttribute('title') || '').toLowerCase();
            const aria = (w.getAttribute('aria-label') || '').toLowerCase();
            const all = `${title} ${aria}`;
            
            let role = null;
            if (all.includes('owner') || all.includes('broadcaster')) role = 'broadcaster';
            else if (all.includes('moderator') || all.includes('mod')) role = 'moderator';
            else if (all.includes('vip')) role = 'vip';
            else if (all.includes('subscriber') || all.includes('sub')) role = 'subscriber';

            if (role && (!highestRole || rolePriority[role] > rolePriority[highestRole])) {
                highestRole = role;
            }
        }

        return highestRole;
    } catch (e) {
        return null;
    }
}

// SVG icons for each role
const ROLE_SVGS = {
    broadcaster: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>`,
    moderator: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
    vip: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    subscriber: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`
};

const WATCHTIME_SVGS = {
    legend: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5C7 4 9 7 9 7"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5C17 4 15 7 15 7"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>`,
    loyal: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h12l4 6-10 13L2 9Z"/><path d="M11 3l1 6"/><path d="M2 9h20"/></svg>`,
    og: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/><path d="M8.5 8.5v.01"/><path d="M16 15.5v.01"/><path d="M12 12v.01"/><path d="M11 17v.01"/><path d="M7 14v.01"/></svg>`
};

const ROLE_CONFIG = {
    broadcaster: { label: 'Broadcaster', color: '#C9A84C' },
    moderator: { label: 'Moderador', color: '#5B9DFF' },
    vip: { label: 'VIP', color: '#A855F7' },
    subscriber: { label: 'Suscriptor', color: '#52B788' }
};

const CUSTOM_BADGE_SVGS = {
    star: 'M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z',
    shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
    heart: 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z',
    zap: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
    crown: 'M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z M3 20h18',
    flame: 'M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z',
    diamond: 'M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z',
    sword: 'M14.5 17.5L3 6V3h3l11.5 11.5 M13 19l6-6 M16 16l4 4 M19 21l2-2',
    skull: 'M12 2a8 8 0 0 0-8 8c0 6 8 12 8 12s8-6 8-12a8 8 0 0 0-8-8z',
    ghost: 'M9 10h.01 M15 10h.01 M12 2a8 8 0 0 0-8 8v12l3-3 2 2 3-3 3 3 2-2 3 3V10a8 8 0 0 0-8-8z',
    rocket: 'M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z',
    music: 'M9 18V5l12-2v13 M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0z M21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z',
    camera: 'M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z M12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
    gamepad: 'M6 12H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2 M6 8h12 M12 8v8',
    trophy: 'M6 9H4.5a2.5 2.5 0 0 1 0-5C7 4 9 7 9 7 M18 9h1.5a2.5 2.5 0 0 0 0-5C17 4 15 7 15 7 M4 22h16 M18 2H6v7a6 6 0 0 0 12 0V2Z',
    medal: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z M8.21 13.89L7 23l5-3 5 3-1.21-9.12',
    flag: 'M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z M4 22v-7',
    bolt: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
    gem: 'M6 3h12l4 6-10 13L2 9z M12 22L2 9h20',
    leaf: 'M11 20A7 7 0 0 1 9.8 6.9C15.5 4.9 17 3.5 19 1c1 2 2 4.5 2 8 0 5.5-4.78 11-10 11z',
    sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.93 4.93l1.41 1.41 M17.66 17.66l1.41 1.41 M2 12h2 M20 12h2',
    moon: 'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z',
    cloud: 'M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z',
    snowflake: 'M12 2v20 M2 12h20 M4.93 4.93l14.14 14.14 M19.07 4.93L4.93 19.07',
    flower: 'M12 7.5a4.5 4.5 0 1 1 4.5 4.5M12 7.5A4.5 4.5 0 1 0 7.5 12',
    fish: 'M6.5 12c.94-3.46 4.94-6 8.5-6 3.56 0 6.06 2.54 7 6-.94 3.47-3.44 6-7 6-3.56 0-7.56-2.53-8.5-6z',
    bird: 'M16 7h.01 M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20',
    cat: 'M12 5c.67 0 1.35.09 2 .26 1.78-2 5.03-2.1 6.96-.09 2.05 2.13.17 4.1-2 3.83 0 .94-.13 1.86-.39 2.73A6.5 6.5 0 0 1 12 18a6.5 6.5 0 0 1-6.57-6.27',
    dog: 'M10 5.172C10 3.782 8.423 2.679 6.5 3c-2.823.47-4.113 6.006-4 7 .08.703 1.725 1.722 3.656 1',
    paw: 'M11.2 2a1.7 1.7 0 0 0-1.58 2.3l.32.96a4.5 4.5 0 0 1-.36 3.58L8 11.5A5.5 5.5 0 0 0 8 18.5h8a5.5 5.5 0 0 0 0-7l-1.58-2.66a4.5 4.5 0 0 1-.36-3.58l.32-.96A1.7 1.7 0 0 0 12.8 2z',
};

const WATCHTIME_CONFIG = [
    { name: 'Legend', minMinutes: 10000, color: '#C9A84C' },
    { name: 'Loyal', minMinutes: 3000, color: '#95D5B2' },
    { name: 'OG', minMinutes: 600, color: '#52B788' }
];

function injectBadges(usernameEl, userData) {
    const container = document.createElement('span');
    container.className = 'shuls-badges-container';
    container.style.cssText = 'display:inline-flex; align-items:center; gap:3px; margin-right:5px; vertical-align:middle;';

    // Determine the single role to show (highest priority only)
    let role = userData.role;
    if (userData.badges && Array.isArray(userData.badges)) {
        const roleBadge = userData.badges.find(b => b.type === 'role');
        if (roleBadge) role = roleBadge.value;
    }

    if (role && ROLE_CONFIG[role]) {
        const cfg = ROLE_CONFIG[role];
        const el = document.createElement('span');
        el.className = 'shuls-badge shuls-badge-role';
        el.style.cssText = `
            display:inline-flex; align-items:center; justify-content:center;
            width:18px; height:18px; border-radius:5px;
            background: ${cfg.color}18; color: ${cfg.color};
            border: 1px solid ${cfg.color}35;
        `;
        el.innerHTML = ROLE_SVGS[role] || '';
        el.title = cfg.label;
        container.appendChild(el);
    }

    // Watch time badge
    let wtBadgeName = userData.watchTimeBadge;
    if (!wtBadgeName && userData.badges) {
        const wtBadge = userData.badges.find(b => b.type === 'watchtime');
        if (wtBadge) wtBadgeName = wtBadge.value;
    }
    if (wtBadgeName) {
        const wtKey = wtBadgeName.toLowerCase();
        const wtCfg = WATCHTIME_CONFIG.find(w => w.name.toLowerCase() === wtKey);
        if (wtCfg) {
            const el = document.createElement('span');
            el.className = 'shuls-badge shuls-badge-wt';
            el.style.cssText = `
                display:inline-flex; align-items:center; justify-content:center;
                width:18px; height:18px; border-radius:5px;
                background: ${wtCfg.color}18; color: ${wtCfg.color};
                border: 1px solid ${wtCfg.color}35;
            `;
            el.innerHTML = WATCHTIME_SVGS[wtKey] || '';
            el.title = `${wtCfg.name} viewer`;
            container.appendChild(el);
        }
    }

    // Custom badges from mod panel
    if (userData.customBadges && userData.customBadges.length > 0) {
        for (const cb of userData.customBadges) {
            const svgPath = CUSTOM_BADGE_SVGS[cb.icon];
            if (!svgPath) continue;
            const el = document.createElement('span');
            el.className = 'shuls-badge shuls-badge-custom';
            el.style.cssText = `
                display:inline-flex; align-items:center; justify-content:center;
                width:18px; height:18px; border-radius:5px;
                background: ${cb.color}18; color: ${cb.color};
                border: 1px solid ${cb.color}35;
            `;
            el.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${cb.color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${svgPath}"/></svg>`;
            el.title = cb.name;
            container.appendChild(el);
        }
    }

    if (container.children.length > 0) {
        usernameEl.insertBefore(container, usernameEl.firstChild);
    }
}

// ========== FLOATING PANEL ==========
let panelUserData = null;
let panelStreamData = null;
let currentTab = 'insignias';

function injectPanel() {
    const el = document.createElement('div');
    el.id = 'shuls-ext-root';
    el.innerHTML = `
        <div class="shuls-fab" id="shuls-fab"><img src="${chrome.runtime.getURL('icons/logo.png')}" alt="S" /></div>
        <div class="shuls-panel hidden" id="shuls-panel">
            <div class="shuls-tabs" id="shuls-tabs">
                <button class="shuls-tab active" data-tab="insignias">Insignias</button>
                <button class="shuls-tab" data-tab="puntos">Puntos</button>
                <button class="shuls-tab" data-tab="cuenta">Cuenta</button>
            </div>
            <div class="shuls-panel-body" id="shuls-body">
                <div class="shuls-loader"></div>
            </div>
        </div>
    `;
    document.body.appendChild(el);

    let panelOpen = false;
    document.getElementById('shuls-fab').addEventListener('click', () => {
        panelOpen = !panelOpen;
        document.getElementById('shuls-panel').classList.toggle('hidden', !panelOpen);
        document.getElementById('shuls-fab').classList.toggle('active', panelOpen);
        if (panelOpen) loadPanel();
    });

    document.getElementById('shuls-tabs').addEventListener('click', (e) => {
        const tab = e.target.closest('.shuls-tab');
        if (!tab) return;
        currentTab = tab.dataset.tab;
        document.querySelectorAll('.shuls-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderTab();
    });
}

function formatDetailedTime(totalMinutes) {
    if (!totalMinutes || totalMinutes === 0) return { text: '0m', days: 0, hours: 0, mins: 0 };
    const days = Math.floor(totalMinutes / 1440);
    const hours = Math.floor((totalMinutes % 1440) / 60);
    const mins = totalMinutes % 60;
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (mins > 0) parts.push(`${mins}m`);
    return { text: parts.join(' ') || '0m', days, hours, mins };
}

async function loadPanel() {
    const body = document.getElementById('shuls-body');
    body.innerHTML = '<div class="shuls-loader"></div>';

    try {
        const response = await chrome.runtime.sendMessage({ type: 'GET_USER_DATA' });

        if (!response || !response.user) {
            document.getElementById('shuls-tabs').style.display = 'none';
            body.innerHTML = `
                <div class="shuls-not-logged">
                    <div class="shuls-not-logged-icon">🔒</div>
                    <p class="shuls-not-logged-text">Conectá tu cuenta para acumular puntos</p>
                    <button class="shuls-cta-btn" id="shuls-login-cta">Conectar con Kick</button>
                </div>
            `;
            document.getElementById('shuls-login-cta').addEventListener('click', () => {
                window.open('http://localhost:5173', '_blank');
            });
            return;
        }

        document.getElementById('shuls-tabs').style.display = 'flex';
        panelUserData = response.user;
        panelStreamData = response.stream;
        renderTab();
    } catch (e) {
        body.innerHTML = '<p class="shuls-err">Error cargando</p>';
    }
}

function renderTab() {
    const body = document.getElementById('shuls-body');
    if (!panelUserData) { body.innerHTML = '<p class="shuls-err">Sin datos</p>'; return; }

    if (currentTab === 'insignias') renderInsigniasTab(body);
    else if (currentTab === 'puntos') renderPuntosTab(body);
    else if (currentTab === 'cuenta') renderCuentaTab(body);
}

function renderInsigniasTab(body) {
    const user = panelUserData;
    const pointsIcon = chrome.runtime.getURL('icons/points.png');

    // Vista previa: show username with equipped badges
    const equippedBadges = (user.badges || []).filter(b => b.equipped);
    const badgePreviewHtml = equippedBadges.map(b => {
        const svgPath = CUSTOM_BADGE_SVGS[b.badge?.icon] || '';
        return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${b.badge?.color || '#52B788'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${svgPath}"/></svg>`;
    }).join('');

    const allBadges = user.badges || [];
    const badgesHtml = allBadges.length > 0 ? allBadges.map(b => {
        const svgPath = CUSTOM_BADGE_SVGS[b.badge?.icon] || '';
        const isEquipped = b.equipped;
        return `
            <div class="shuls-badge-preview">
                <div class="shuls-badge-preview-icon" style="background:${(b.badge?.color || '#52B788')}15; color:${b.badge?.color || '#52B788'}">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${b.badge?.color || '#52B788'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${svgPath}"/></svg>
                </div>
                <span class="shuls-badge-preview-name">${b.badge?.name || 'Insignia'}</span>
                <span class="shuls-badge-preview-status" style="background:${isEquipped ? 'rgba(82,183,136,0.1)' : 'rgba(255,255,255,0.05)'}; color:${isEquipped ? '#52B788' : '#71717a'}">${isEquipped ? '✓' : '—'}</span>
            </div>`;
    }).join('') : '<p style="color:#71717a;font-size:11px;text-align:center;padding:16px 0;">Mirá streams y participá en el chat para desbloquear insignias.</p>';

    body.innerHTML = `
        <div style="font-size:10px;color:#71717a;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">VISTA PREVIA</div>
        <div style="display:flex;align-items:center;gap:6px;padding:10px;background:rgba(255,255,255,0.03);border-radius:8px;margin-bottom:14px;">
            ${badgePreviewHtml}
            <span style="font-size:13px;font-weight:700;color:#fff;">${user.displayName || user.kickUsername}</span>
        </div>
        <div style="font-size:10px;color:#71717a;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">TUS INSIGNIAS</div>
        ${badgesHtml}
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:12px;">
            <span style="font-size:10px;color:#71717a;">${equippedBadges.length}/${allBadges.length > 0 ? Math.min(allBadges.length, 3) : 3} seleccionadas</span>
            <a href="http://localhost:5173/profile" target="_blank" class="shuls-save-btn" style="width:auto;padding:6px 14px;margin:0;text-decoration:none;text-align:center;">Guardar</a>
        </div>
    `;
}

function renderPuntosTab(body) {
    const user = panelUserData;
    const stream = panelStreamData;
    const pointsIcon = chrome.runtime.getURL('icons/points.png');
    const wt = formatDetailedTime(user.totalWatchTime);

    body.innerHTML = `
        <div class="shuls-pts-row">
            <img src="${pointsIcon}" class="shuls-pts-icon" alt="">
            <span class="shuls-pts-num">${user.points?.toLocaleString() || 0}</span>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">🕐</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Watchtime</span>
                <span class="shuls-info-desc">Obtené puntos por mirar el directo.</span>
                <span class="shuls-info-val">10 pts cada 10 min</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">💬</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Chat</span>
                <span class="shuls-info-desc">Máximo 1 vez cada 2 minutos.</span>
                <span class="shuls-info-val">0.15 pts por minuto</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">✦</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Cofre</span>
                <span class="shuls-info-desc">Subs +50%</span>
                <span class="shuls-info-val">40 pts</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">🎁</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Recompensa de Chat</span>
                <span class="shuls-info-desc">Solo una persona puede reclamarlo.</span>
                <span class="shuls-info-val">50~180 pts</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">🔥</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Racha de Streams</span>
                <span class="shuls-info-desc">Mirá streams consecutivos.</span>
                <span class="shuls-info-val">Hasta 250 pts</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon">⭐</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Suscriptores</span>
                <span class="shuls-info-desc">Multiplicadores para subs.</span>
                <span class="shuls-info-val" style="color:#52B788;">+50% cofres y chat</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon" style="color:#f59e0b;">☀</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Happy Hour</span>
                <span class="shuls-info-val" style="color:#f59e0b;">x1.25 watchtime</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon" style="color:#eab308;">✦</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Golden Hour</span>
                <span class="shuls-info-val" style="color:#eab308;">x1.4 watchtime - x2 chat</span>
            </div>
        </div>
        <div class="shuls-info-row">
            <div class="shuls-info-icon" style="color:#a78bfa;">◆</div>
            <div class="shuls-info-text">
                <span class="shuls-info-title">Netherite Hour</span>
                <span class="shuls-info-val" style="color:#a78bfa;">x1.25 watchtime</span>
            </div>
        </div>
    `;
}

function renderCuentaTab(body) {
    const user = panelUserData;
    const stream = panelStreamData;
    const wt = formatDetailedTime(user.totalWatchTime);

    body.innerHTML = `
        <div class="shuls-acct-row">
            <span class="shuls-acct-label">Twitch Points</span>
            <span class="shuls-acct-value">${user.twitchPointsAmount || 0}</span>
        </div>
        <div class="shuls-acct-row">
            <span class="shuls-acct-label">Kick Points</span>
            <span class="shuls-acct-value">${user.points?.toLocaleString() || 0}</span>
        </div>
        <div class="shuls-acct-row">
            <span class="shuls-acct-label">XP</span>
            <span class="shuls-acct-value">${(user.points ? (user.points * 0.061).toFixed(1) : 0)}</span>
        </div>
        <div class="shuls-acct-row">
            <span class="shuls-acct-label">Watchtime</span>
            <span class="shuls-acct-value">${wt.text || '0m'}</span>
        </div>
        <div class="shuls-acct-row">
            <span class="shuls-acct-label">Racha de Streams</span>
            <span class="shuls-acct-value">${user.currentStreak || 0}</span>
        </div>
        <div style="display:flex;gap:6px;margin-top:12px;">
            <a href="http://localhost:5173/profile" target="_blank" class="shuls-save-btn" style="text-decoration:none;text-align:center;">Ver Perfil</a>
            <a href="http://localhost:5173/rewards" target="_blank" class="shuls-save-btn" style="text-decoration:none;text-align:center;">🎁 Rewards</a>
        </div>
    `;
}

async function fetchChatConfig() {
    try {
        const r = await fetch(`${API_URL}/api/extension/chat-config`);
        if (r.ok) return await r.json();
    } catch (e) {}
    return null;
}

// ========== FALLING GIFT DROP ==========
let giftDropTimer = null;
let giftIsLive = false;

function startGiftDropSystem() {
    // Check stream status every 30s and schedule gift drops when live
    checkAndScheduleGift();
    setInterval(checkAndScheduleGift, 30000);
}

async function checkAndScheduleGift() {
    try {
        const response = await chrome.runtime.sendMessage({ type: 'GET_USER_DATA' });
        const wasLive = giftIsLive;
        giftIsLive = response?.stream?.isLive || false;

        if (giftIsLive && !wasLive) {
            console.log('[Shuls] Stream is live — gift drops enabled');
            scheduleNextGift();
        } else if (!giftIsLive && wasLive) {
            console.log('[Shuls] Stream offline — gift drops disabled');
            if (giftDropTimer) { clearTimeout(giftDropTimer); giftDropTimer = null; }
        }
    } catch (e) {}
}

function scheduleNextGift() {
    if (giftDropTimer) clearTimeout(giftDropTimer);
    // Random interval: 3 to 8 minutes
    const delay = (Math.random() * 5 + 3) * 60 * 1000;
    console.log(`[Shuls] Next gift drop in ${(delay / 60000).toFixed(1)} min`);
    giftDropTimer = setTimeout(() => {
        if (giftIsLive) {
            spawnGiftDrop();
            scheduleNextGift();
        }
    }, delay);
}

function spawnGiftDrop() {
    // Find the chat container to drop the gift in
    const chatContainer = document.querySelector('#chatroom') ||
        document.querySelector('[class*="chat-container"]') ||
        document.querySelector('[data-chat-entry]')?.parentElement?.parentElement;

    if (!chatContainer) return;

    const rect = chatContainer.getBoundingClientRect();
    if (rect.width < 50 || rect.height < 50) return;

    const gift = document.createElement('div');
    gift.className = 'shuls-gift-drop';
    // Random horizontal position within chat
    const leftPos = Math.random() * (rect.width - 40) + rect.left;
    const fallDuration = 6 + Math.random() * 4; // 6-10 seconds

    gift.style.cssText = `
        left: ${leftPos}px;
        top: ${rect.top - 40}px;
        position: fixed;
        animation-duration: ${fallDuration}s;
    `;
    gift.innerHTML = `<img src="${chrome.runtime.getURL('icons/points.png')}" style="width:32px;height:32px;pointer-events:none;">`;

    document.body.appendChild(gift);

    // Click handler
    gift.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        gift.remove();
        await claimGift();
    });

    // Remove after animation ends
    setTimeout(() => {
        if (gift.parentNode) gift.remove();
    }, fallDuration * 1000 + 500);
}

async function claimGift() {
    try {
        const token = await getStoredToken();
        if (!token) return;

        const r = await fetch(`${API_URL}/api/users/gift-claim`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (r.ok) {
            const data = await r.json();
            showGiftClaimed(data.amount);
        }
    } catch (e) {
        console.error('[Shuls] Gift claim error:', e);
    }
}

async function getStoredToken() {
    try {
        const data = await chrome.storage.local.get('token');
        return data.token || null;
    } catch (e) { return null; }
}

function showGiftClaimed(amount) {
    const popup = document.createElement('div');
    popup.className = 'shuls-gift-claim';
    popup.innerHTML = `<span>+${amount} pts</span><small>🎁 ¡Regalo reclamado!</small>`;
    document.body.appendChild(popup);
    setTimeout(() => {
        popup.style.transition = 'opacity 0.5s';
        popup.style.opacity = '0';
        setTimeout(() => popup.remove(), 500);
    }, 2000);
}
